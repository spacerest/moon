from moon.tests import cache, general 
import unittest

unittest.main(cache, exit=False)

unittest.main(general)
